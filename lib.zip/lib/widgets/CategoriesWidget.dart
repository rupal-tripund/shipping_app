import 'package:flutter/material.dart';
import '../../constants/styles.dart';
class CategoriesWidget extends StatelessWidget {
  dynamic categories = {1:'Electronics',2:'Hair Appliances',3:'Beauty Products', 4:'Grocery', 5:'Kitchen Appliances',6:'Men',7:'Women Ethnic'};
   CategoriesWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
          Padding(padding: EdgeInsets.only(left: 10,right: 10,bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Category",
                  style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Style.loginPageBackgroundColor,
                  ),
                ),
                Text("See All",
                  style: TextStyle(
                   fontSize:15,
                    fontWeight:FontWeight.bold,
                    color:  Style.loginPageBackgroundColor,

                  ),
                )
              ],
            ),
          ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
            child: Row(
             // mainAxisAlignment: MainAxisAlignment.start,
            children: [
            for (int i=1; i<8; i++)
            Container(
            margin: EdgeInsets.symmetric(horizontal: 10,vertical: 5),
              height: 100,
              decoration: BoxDecoration(
                borderRadius:
                  BorderRadius.circular(10),
                color: Colors.white,
              boxShadow:[
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                      spreadRadius:1,
                      blurRadius: 6
                )
              ]),

                child: Row(
                children: [
            Padding(
              padding: EdgeInsets.all(5),
              child: Image.asset("assets/images/$i.jpg",
              height: 100,
                  width: 100,
              ),

            ),
                  Padding(padding:EdgeInsets.only(right: 5),
                    child: Text(categories[i],
                    style:TextStyle(
                      fontSize: 26 ,
                      fontWeight: FontWeight.bold
                    )
                    ),

                  )

                ],
              ),
            )
            ],
            ),
            )
      ],
    );
  }
}
